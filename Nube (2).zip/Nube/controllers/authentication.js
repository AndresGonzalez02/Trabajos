import { loginvalidation } from "../controllers/global.js";

const loginin = document.getElementById("botonlog")

async function validar(){
    const email = document.getElementById("userlogin").value
    const pass = document.getElementById("passlogin").value

    const verificar = loginvalidation(email,pass)
    const validation = await verificar

    if (validation != null){
        alert ('Authentication sucessfull '+email)
        window.location.href='../templates/pagina.html'
    }
    else {
        alert('Error authentication no sucessfull ')
        console.log('sesion '+email+'no validation')
    }
    
}

window.addEventListener('DOMContentLoaded',async()=>{
    loginin.addEventListener('click', validar)
})